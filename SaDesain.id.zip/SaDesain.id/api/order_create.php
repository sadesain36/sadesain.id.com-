<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');
if($_SERVER['REQUEST_METHOD']!=='POST'){echo json_encode(['ok'=>false,'message'=>'Metode tidak valid.']);exit;}
$name=trim($_POST['customer_name']??''); $email=trim($_POST['email']??''); $wa=trim($_POST['whatsapp']??'');
$type=trim($_POST['design_type']??''); $desc=trim($_POST['description']??'');
if(!$name||!filter_var($email,FILTER_VALIDATE_EMAIL)||!$wa||!$type||!$desc){echo json_encode(['ok'=>false,'message'=>'Lengkapi semua data wajib.']);exit;}
$wordCount=preg_match_all('/\S+/u',$desc,$matches);
if($wordCount>50){echo json_encode(['ok'=>false,'message'=>'Catatan pesanan maksimal 50 kata.']);exit;}
do{$code='SD-'.strtoupper(substr(bin2hex(random_bytes(5)),0,8));$q=$pdo->prepare("SELECT id FROM orders WHERE tracking_code=?");$q->execute([$code]);}while($q->fetch());
$stmt=$pdo->prepare("INSERT INTO orders(tracking_code,customer_name,email,whatsapp,design_type,description) VALUES(?,?,?,?,?,?)");
$stmt->execute([$code,$name,$email,$wa,$type,$desc]);
echo json_encode(['ok'=>true,'tracking_code'=>$code]);
