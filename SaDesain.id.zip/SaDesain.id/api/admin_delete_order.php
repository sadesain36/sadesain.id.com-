<?php
require_once __DIR__.'/../config.php'; secure_session_start(); header('Content-Type: application/json; charset=utf-8');
if(empty($_SESSION['admin_id'])){http_response_code(401);echo json_encode(['ok'=>false,'message'=>'Sesi admin habis.']);exit;} verify_csrf($_POST['csrf_token']??'');$id=(int)($_POST['id']??0);if(!$id){echo json_encode(['ok'=>false,'message'=>'ID tidak valid.']);exit;}$stmt=$pdo->prepare('DELETE FROM orders WHERE id=?');$stmt->execute([$id]);echo json_encode(['ok'=>true]);
