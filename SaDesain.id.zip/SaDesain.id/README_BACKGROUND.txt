PEMBARUAN BACKGROUND SADESAIN.ID

Background website sudah diganti menggunakan gambar yang diberikan pengguna:
assets/background.png

Gambar tersebut dipakai sebagai:
1. Background utama seluruh halaman website (fixed, cover, tidak diulang).
2. Background hero/beranda.
3. Section dibuat semi-transparan agar background tetap terlihat tetapi teks tetap mudah dibaca.

Jika ingin mengganti background lagi, cukup ganti file:
assets/background.png

Tidak perlu mengubah coding.
