const $=s=>document.querySelector(s);
$('#menu')?.addEventListener('click',()=>$('#navlinks').classList.toggle('open'));
document.querySelectorAll('.nav a').forEach(a=>a.addEventListener('click',()=>$('#navlinks').classList.remove('open')));

const io=new IntersectionObserver(es=>es.forEach(e=>e.isIntersecting&&e.target.classList.add('show')),{threshold:.1});
document.querySelectorAll('.cards article,.work,.section').forEach(x=>x.classList.add('reveal'));
document.querySelectorAll('.reveal').forEach(x=>io.observe(x));

function openPreview(el){$('#previewImg').src=el.dataset.image;$('#previewTitle').textContent=el.dataset.title;$('#preview').classList.add('show')}
function closePreview(){$('#preview').classList.remove('show')}

$('#orderForm')?.addEventListener('submit',async e=>{
 e.preventDefault();
 const fd=new FormData(e.target);
 const r=await fetch('api/order_create.php',{method:'POST',body:fd}).then(x=>x.json()).catch(()=>({ok:false,message:'Server tidak dapat dihubungi.'}));
 const box=$('#orderResult');
 if(r.ok){
   const data=Object.fromEntries(fd.entries());
   const waText=`Halo SaDesain.id, saya ingin memesan desain.%0A%0AKode Tracking: ${r.tracking_code}%0ANama: ${encodeURIComponent(data.customer_name)}%0AEmail: ${encodeURIComponent(data.email)}%0AWhatsApp: ${encodeURIComponent(data.whatsapp)}%0AJenis Desain: ${encodeURIComponent(data.design_type)}%0ABudget: ${encodeURIComponent(data.budget||'Belum ditentukan')}%0ADetail: ${encodeURIComponent(data.description)}`;
   const waUrl=`https://wa.me/628134947692?text=${waText}`;
   box.innerHTML=`<div class="success"><b>Pesanan berhasil dibuat!</b><br>Kode tracking Anda: <strong>${r.tracking_code}</strong><br>Simpan kode ini untuk memantau proses desain.<div class="result-actions"><a class="btn primary" href="${waUrl}" target="_blank" rel="noopener">💬 Kirim Detail ke WhatsApp</a><a class="btn secondary" href="#tracking" onclick="document.querySelector('#trackingCode').value='${r.tracking_code}'">Lacak Pesanan</a></div></div>`;
   window.open(waUrl,'_blank','noopener');
   e.target.reset();
 }else box.innerHTML=`<div class="success" style="background:#fff1f2;color:#9f1239;border-color:#fecdd3">${r.message||'Pesanan gagal.'}</div>`;
});

$('#trackingForm')?.addEventListener('submit',async e=>{
 e.preventDefault();
 const code=$('#trackingCode').value.trim();
 const r=await fetch('api/order_track.php?code='+encodeURIComponent(code)).then(x=>x.json()).catch(()=>({ok:false,message:'Gagal menghubungi server.'}));
 const box=$('#trackingResult');
 if(!r.ok){box.innerHTML=`<div class="track-card"><b>${r.message||'Pesanan tidak ditemukan.'}</b></div>`;return}
 const order=r.order, statuses=['Menunggu','Diterima','Diproses','Revisi','Selesai'], idx=statuses.indexOf(order.status);
 box.innerHTML=`<div class="track-card">
   <h3>${order.tracking_code}</h3><p><b>${order.customer_name}</b> — ${order.design_type}</p>
   <span class="status">${order.status}</span>
   <div class="steps">${statuses.map((s,i)=>`<div class="step ${i<=idx?'active':''}">${s}</div>`).join('')}</div>
   <p><b>Designer:</b> ${order.designer_name||'Akan ditentukan admin'}</p>
   ${order.admin_note?`<div class="note"><b>Catatan dari SaDesain:</b><br>${order.admin_note}</div>`:''}
   <small>Terakhir diperbarui: ${order.updated_at}</small>
 </div>`;
});
