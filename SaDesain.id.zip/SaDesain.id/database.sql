CREATE DATABASE IF NOT EXISTS sadesain CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sadesain;

CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  photo VARCHAR(255) DEFAULT 'assets/admin.png',
  role VARCHAR(50) DEFAULT 'Administrator',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  site_name VARCHAR(100) NOT NULL DEFAULT 'SaDesain.id',
  tagline VARCHAR(255) NOT NULL DEFAULT 'Jasa desain kreatif untuk kebutuhan Anda',
  whatsapp VARCHAR(30) DEFAULT '628134947692',
  email VARCHAR(150) DEFAULT 'sadesain.id@gmail.com',
  background VARCHAR(255) DEFAULT 'assets/background.png',
  logo VARCHAR(255) DEFAULT 'assets/logo.png',
  instagram VARCHAR(255) DEFAULT '',
  facebook VARCHAR(255) DEFAULT '',
  tiktok VARCHAR(255) DEFAULT ''
);

CREATE TABLE IF NOT EXISTS portfolios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  description TEXT,
  image VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- Upgrade aman jika database lama sudah pernah dibuat
ALTER TABLE settings ADD COLUMN IF NOT EXISTS instagram VARCHAR(255) DEFAULT '';
ALTER TABLE settings ADD COLUMN IF NOT EXISTS facebook VARCHAR(255) DEFAULT '';
ALTER TABLE settings ADD COLUMN IF NOT EXISTS tiktok VARCHAR(255) DEFAULT '';
ALTER TABLE orders ADD COLUMN IF NOT EXISTS price VARCHAR(80) DEFAULT '';
ALTER TABLE orders DROP COLUMN IF EXISTS budget;

CREATE TABLE IF NOT EXISTS members (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  position VARCHAR(150) DEFAULT 'Anggota Kelompok',
  bio TEXT,
  photo VARCHAR(255) DEFAULT 'assets/admin.png',
  active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS designers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  specialty VARCHAR(150) DEFAULT 'Graphic Designer',
  photo VARCHAR(255) DEFAULT 'assets/admin.png',
  active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tracking_code VARCHAR(30) NOT NULL UNIQUE,
  customer_name VARCHAR(120) NOT NULL,
  email VARCHAR(150) NOT NULL,
  whatsapp VARCHAR(30) NOT NULL,
  design_type VARCHAR(100) NOT NULL,
  description TEXT NOT NULL,
  price VARCHAR(80) DEFAULT '',
  designer_id INT NULL,
  status ENUM('Menunggu','Diterima','Diproses','Revisi','Selesai') NOT NULL DEFAULT 'Menunggu',
  admin_note TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (designer_id) REFERENCES designers(id) ON DELETE SET NULL
);

INSERT INTO settings (id, site_name, tagline, whatsapp, email, background, logo, instagram, facebook, tiktok) VALUES (1,'SaDesain.id','Jasa desain kreatif untuk kebutuhan Anda','628134947692','sadesain.id13@gmail.com','assets/background.png','assets/logo.png','https://www.instagram.com/sadesain.id_?igsi=aDExa3F1dzlzMzlu','https://www.facebook.com/profile.php?id=61592431325858','https://www.tiktok.com/@sadesainid?_r=1&_t=ZS-99ERqGPsxBR') ON DUPLICATE KEY UPDATE site_name=VALUES(site_name),tagline=VALUES(tagline),whatsapp=VALUES(whatsapp),email=VALUES(email),instagram=VALUES(instagram),facebook=VALUES(facebook),tiktok=VALUES(tiktok);

INSERT INTO admins (name,email,password_hash,photo,role)
SELECT 'Admin SaDesain','admin@sadesain.id', '$2y$12$vIOGrGt2c1lNh1x2EPuL9ecXQWJANw2iOY3uZRNZMHC80xuvfg8TW', 'assets/admin.png', 'Administrator'
WHERE NOT EXISTS (SELECT 1 FROM admins WHERE email='admin@sadesain.id');

INSERT INTO designers (name,specialty,photo)
SELECT 'Dendi','Creative Director / Designer','assets/admin.png'
WHERE NOT EXISTS (SELECT 1 FROM designers WHERE name='Dendi');

INSERT INTO members (name,position,bio,photo,active)
SELECT 'Ahmad','Anggota Kelompok','Anggota tim SaDesain.id.','assets/team/ahmad.jpeg',1
WHERE NOT EXISTS (SELECT 1 FROM members WHERE name='Ahmad');
INSERT INTO members (name,position,bio,photo,active)
SELECT 'Dirro','Anggota Kelompok','Anggota tim SaDesain.id.','assets/team/dirro.jpeg',1
WHERE NOT EXISTS (SELECT 1 FROM members WHERE name='Dirro');

INSERT IGNORE INTO portfolios (id,title,description,image) VALUES
(1,'Logo SaDesain.id','Identitas visual SaDesain.id.','assets/logo.png'),
(2,'Banner Promosi','Contoh desain banner dan spanduk promosi.','assets/banner.png'),
(3,'Mockup Produk','Contoh katalog mockup kemasan produk.','assets/mockup.png'),
(4,'Desain Kaos','Contoh desain merchandise dan kaos.','assets/kaos.png');
