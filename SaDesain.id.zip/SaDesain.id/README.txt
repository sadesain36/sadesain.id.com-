SaDesain.id — Paket Website + Admin Aman
========================================

FITUR ADMIN BARU
- Login admin dengan session cookie HttpOnly/SameSite.
- Regenerasi session ID setelah login.
- Password memakai password_hash/password_verify.
- Proteksi CSRF untuk aksi admin.
- Batas 5 percobaan login per 10 menit pada sesi login.
- Halaman admin memakai noindex,nofollow.
- Header keamanan dasar pada /admin.
- Kelola pesanan: lihat, pilih designer, ubah status, beri catatan, hapus.
- Kelola portfolio: tambah, edit, hapus, upload gambar JPG/PNG/WEBP.
- Kelola designer: tambah, edit, hapus, upload foto.
- Kelola anggota kelompok: tambah, edit, hapus, ganti foto. Data tidak ditampilkan di publik.
- Pengaturan website: nama, tagline, WhatsApp, email, Instagram, Facebook, TikTok, logo/background path.
- Ganti password admin dari dashboard.
- Website publik tetap menyediakan pemesanan, tracking, media sosial, dan WhatsApp mengambang.

LOGIN DEMO AWAL
Email: admin@sadesain.id
Password: admin123

WAJIB: Setelah login pertama, buka Admin > Keamanan dan ganti password sebelum website dipublikasikan.

INSTALASI XAMPP
1. Ekstrak folder ke C:\xampp\htdocs\
2. Jalankan Apache dan MySQL.
3. Import database.sql melalui phpMyAdmin.
4. Buka website: http://localhost/NAMA_FOLDER/
5. Admin: http://localhost/NAMA_FOLDER/admin/login.php

DATABASE HOSTING
Untuk hosting, ubah konfigurasi database pada config.php atau gunakan environment variables:
SADESAIN_DB_HOST, SADESAIN_DB_NAME, SADESAIN_DB_USER, SADESAIN_DB_PASS.

CATATAN KEAMANAN PRODUKSI
- Gunakan HTTPS.
- Ganti password demo.
- Jangan memberikan akses folder admin kepada pengguna biasa.
- Gunakan user database khusus dengan hak minimum, bukan root.
- Backup database secara berkala.
- Batasi ukuran upload pada server dan pastikan folder upload tidak dapat mengeksekusi PHP.
